<template>
  <nav class="navBar">
    <div class="container-fluid" style="padding-top: 8px;">
      <div class="row">
        <div class="col-lg-4">
          <div class="leftNavbar">
          </div>
        </div>
        <div class="col-lg-4">
          <h3 style="text-align: center; color: #ead044; font-family: Georgia, 'Times New Roman', Times, serif">FILMDIZIMOB</h3>
        </div>
        <div class="col-lg-4">
          <div class="rightNavbar">
            <ul>
              <li>Filmler</li>
              <li>Diziler</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>


<script>
export default {
  mounted() {
    console.log("Done Mount.");
  }
};
</script>
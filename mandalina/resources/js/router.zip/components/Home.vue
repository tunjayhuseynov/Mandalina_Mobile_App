<template>
    <div>
        <navbar></navbar>
        <carousel type="movies"></carousel> 
    </div>
</template>

<script>
export default {
  mounted() {
    console.log("Done Mount.");
  }
};
</script>